const { SlashCommandBuilder } = require("@discordjs/builders");
const { EmbedBuilder } = require("discord.js");
const config = require("../config.js");
const db = require("../models/schema.js");
module.exports = {
  data: new SlashCommandBuilder()
    .setName("ping")
    .setDescription("Botun gecikme bilgilerini gösterir."),
  run: async (client, interaction) => {
      if(!interaction.guild) return interaction.reply("Bu komut dmden kullanılamaz.");
  var mongoose = require("mongoose");

    let a = "";

    let b = mongoose.connection.readyState;

    if (b === 0) a = "Bağlantı Koptu";

    if (b === 1) a = "Bağlı";

    if (b === 2) a = "Bağlanılıyor";

    if (b === 3) a = "Bağlantı Kesiliyor";

    if (b === 99) a = "Aktif Degil";

    let x = await db.find();
      const embed = new EmbedBuilder()
      .setThumbnail(client.user.avatarURL())
      .setColor("Blue")
      .setAuthor({
        name: "Alvi",
        iconURL: client.user.avatarURL({ dynamic: true }),
      })
      .setDescription(`Ping : ${client.ws.ping}\n ${a}`);

    interaction.reply({ embeds: [embed] });
  },
};
