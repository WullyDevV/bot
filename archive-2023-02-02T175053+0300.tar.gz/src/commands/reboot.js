const { SlashCommandBuilder } = require("@discordjs/builders");

const { EmbedBuilder, ButtonBuilder, ActionRowBuilder, ButtonStyle }  = require('discord.js');

let client = global.client

 module.exports = {

    data: new SlashCommandBuilder()

    .setName('reboot')

    .setDescription("Bot, kendisini baştan başlatır."),

    run: async (client, interaction) => {  
if(!interaction.guild) return interaction.reply("Bu komut dmden kullanılamaz.");
        if(interaction.user.id !== "1062005290997915688") return ;

        process.exit(1)

    }

 }

