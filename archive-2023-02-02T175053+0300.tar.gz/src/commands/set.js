
const { SlashCommandBuilder } = require("@discordjs/builders");
const {ActivityType} = require("discord.js")

module.exports = {

data: new SlashCommandBuilder()

.setName("durum")

.addStringOption(option =>

    option.setName('mesaj')

        .setDescription('Durum mesajını yaz')

        .setRequired(true))

.addStringOption(option =>

    option.setName('durum')

        .setDescription('durum seç')

        .setRequired(true)

        .addChoices(

            { name: 'Online', value: 'online' },

            { name: 'Idle', value: 'idle' },

            { name: 'Dnd', value: 'dnd' },

        ))

.setDescription("Botun durumunu değiştirir"),

run: async (client, interaction) => {

const message = await interaction.deferReply({

    fetchReply:true

})

if(interaction.user.id !== "1062005290997915688") return interaction.editReply("Bu komutu sadece bot sahibi kullanabilir")

const mesaj = interaction.options.getString('mesaj')

const durum = interaction.options.getString('durum')

client.user.setPresence({

    activities: [{ name: mesaj, type: ActivityType.Watching }],

    status: durum,

  });

let durumEmoji

if(durum === "online")durumEmoji = "🟢"

if(durum === "idle")durumEmoji = "🟡"

if(durum === "dnd")durumEmoji = "🔴"

interaction.editReply({content:"Durum başarıyla "+durumEmoji+" "+durum+" olarak değiştirildi!"})

}

}

