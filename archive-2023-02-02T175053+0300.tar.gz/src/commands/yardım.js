

const { SlashCommandBuilder } = require("@discordjs/builders");

const { EmbedBuilder } = require("discord.js");

const config = require("../config.js");

module.exports = {

    data: new SlashCommandBuilder()

        .setName("yardım")

        .setDescription("Botun yardım menüsünü gösterir."),

    run: async (client, interaction) => {

        if (!interaction.guild) return interaction.reply("Bu komut dmden kullanılamaz.");

        const embed = new EmbedBuilder()

            .setThumbnail(client.user.avatarURL())

            .setColor("Blue")
.setTitle("Buglar FİX") 
            .setAuthor({ name: "Alvi", iconURL: client.user.avatarURL({ dynamic: true }) })

            .setDescription(`

**</deprem otomatik-kur:1031644654443188304>**

Otomatik Kanal Açar Ve Sistemi Oraya Entegre Eder

**</deprem aç:1031644654443188304>**

Sistemi Açarsanız

**</deprem ayarlar:1031644654443188304>**

Yaptığınız Ayarları Gösterir

**</deprem kanal:1031644654443188304>**

Botun Hangi Kanala Entegre Edeceğini Belirlersiniz

**</deprem sıfırla:1031644654443188304>**

Yaptığınız Ayarları Sıfırlar

**</deprem son-depremler:1031644654443188304>**

Son 1-20 Arasındaki Depremleri Gösterir

**</istatistik:1031644654443188304>**

Botun İstatistiği

**</ping:1031644654443188304>**

Pong

**</reboot:1031644654443188304>**

(Sahip) Bot Yeniden Başlar

**</durum:1031644654443188304>**

(Sahip) Botun Durumunu Ayarlar`)

        

            

        

        interaction.reply({ embeds: [embed] })

    }

} 