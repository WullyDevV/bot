module.exports = {
  token: "MTAzMTY0NDY1NDQ0MzE4ODMwNA.GIIiSU.g8gK3uuXTUedrv3fK9EjvG9il4i80n71eu3zUM",
  mongo: "mongodb+srv://AlviBotDeprem:rbOW5Oj9PlKSsnnS@cluster0.dnxm1.mongodb.net/?retryWrites=true&w=majority",
  davet: "https://discord.com/api/oauth2/authorize?client_id=1031644654443188304&permissions=8&scope=bot%20applications.commands",
  destek: "https://discord.gg/YR6tZKVy"
}
