



const { EmbedBuilder, InteractionType } = require('discord.js')

const { readdirSync } = require('fs')

const blacklist = require('../models/karaListe.js')

module.exports = {

    name: 'interactionCreate',

    execute: async (interaction) => {

        let client = interaction.client;

        if (interaction.type == InteractionType.ApplicationCommand) {

            if (interaction.user.bot) return;

            readdirSync('./src/commands').forEach(async file => {

                const command = require(`../../src/commands/${file}`)

                if (interaction.commandName.toLowerCase() === command.data.name.toLowerCase()) {

                    const Embed = new EmbedBuilder().setColor('#5865F2').setTitle('Conyalilar crubu!').setTimestamp().setFooter({ text: 'abi', iconURL: 'https://media.discordapp.net/attachments/1068952034394525846/1069996191170965584/old-ayakcilar-36-5-filan-aramaz-direk-yer-v0-couk1r45kne91.jpg' })

                    const data = await blacklist.findOne({ userID: interaction.user.id })

                    if (data) return interaction.reply({ embeds: [Embed.setDescription(`> Üzgünüm ama konyalıların botu kullanması yasaklandı.`)] })

                    command.run(client, interaction)

                }

            })

        }

    }

}