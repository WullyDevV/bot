



const mongoose = require('mongoose')

const karaListe = new mongoose.Schema({

    userID: String,

    date: String

})

module.exports = mongoose.model('karaListe', karaListe)

